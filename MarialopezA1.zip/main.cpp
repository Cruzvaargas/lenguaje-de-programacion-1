/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>
using namespace std;

int main()
{
    printf("introduce tu edad " );

    int edad = 0;
    cin>> edad;
    if(edad>=18){
    cout<<"el usuario es mayor de edad";
    } 
    else{
    cout<<"el usuario es menor de edad";
}
    return 0;
}
